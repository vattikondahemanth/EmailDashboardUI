import { Component } from '@angular/core';

@Component({
  templateUrl: 'brand-buttons.component.html'
})
export class BrandButtonsComponent {

  constructor() { }

}
